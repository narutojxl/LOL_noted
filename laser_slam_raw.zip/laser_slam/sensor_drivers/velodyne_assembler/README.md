velodyne_assembler
==================

A node for assembling Velodyne scan packages into undistorted 360 degrees scans using IMU and wheel odometry data.
