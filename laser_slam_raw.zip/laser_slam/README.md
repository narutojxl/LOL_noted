# laser_slam
This repository provides an end-to-end system to laser-based graph SLAM using laser point clouds. The code is open-source (BSD License). 

Please consult the *SegMatch* [repository](https://github.com/ethz-asl/segmatch) and [wiki](https://github.com/ethz-asl/segmatch/wiki) for installation instructions and demonstrations.

A stand-alone demonstration and several new features will be added soon!
