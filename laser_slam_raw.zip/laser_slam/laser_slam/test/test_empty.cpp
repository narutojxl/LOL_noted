#include <gtest/gtest.h>

TEST(LaserSlamTestSuite, test_empty) {
  ASSERT_TRUE(true);
}