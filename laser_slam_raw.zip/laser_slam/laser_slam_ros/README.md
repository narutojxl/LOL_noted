laser_slam_ros
==================

A thin laser_slam ros wrapper.